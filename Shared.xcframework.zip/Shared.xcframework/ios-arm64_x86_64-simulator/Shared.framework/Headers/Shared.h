#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SharedAnalytics, SharedSuperProperties, SharedDestination, SharedKotlinEnumCompanion, SharedKotlinEnum<E>, SharedKotlinArray<T>, SharedIdentifyProperties, SharedIdentifyEvent, SharedSuperPropertiesCompanion, SharedTimeEvent, SharedTrackEvent, SharedTrackProperties, SharedAccountDeletionStatus, SharedPermissionSource, SharedPermissionSourceAccount, SharedPermissionSourceBillDetails, SharedPermissionSourceBillSubmitted, SharedPrivacyDashboardStatus, SharedProductExposureSource, SharedTabBarItem;

@protocol SharedAnalyticsReceiver, SharedErrorTracker, SharedEventTracker, SharedIdentifyTracker, SharedPlatform, SharedKotlinComparable, SharedAnalyticEvent, SharedKotlinIterator;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface SharedBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface SharedBase (SharedBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface SharedMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SharedMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorSharedKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface SharedNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface SharedByte : SharedNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface SharedUByte : SharedNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface SharedShort : SharedNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface SharedUShort : SharedNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface SharedInt : SharedNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface SharedUInt : SharedNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface SharedLong : SharedNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface SharedULong : SharedNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface SharedFloat : SharedNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface SharedDouble : SharedNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface SharedBoolean : SharedNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Analytics")))
@interface SharedAnalytics : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)analytics __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedAnalytics *shared __attribute__((swift_name("shared")));
- (void)flush __attribute__((swift_name("flush()")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)setAnalyticsReceiverAnalyticsReceiver:(id<SharedAnalyticsReceiver>)analyticsReceiver __attribute__((swift_name("setAnalyticsReceiver(analyticsReceiver:)")));
@property id<SharedErrorTracker> error __attribute__((swift_name("error")));
@property id<SharedEventTracker> event __attribute__((swift_name("event")));
@property id<SharedIdentifyTracker> identify __attribute__((swift_name("identify")));
@property SharedSuperProperties *superProperties __attribute__((swift_name("superProperties")));
@end

__attribute__((swift_name("Platform")))
@protocol SharedPlatform
@required
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IOSPlatform")))
@interface SharedIOSPlatform : SharedBase <SharedPlatform>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("AnalyticEvent")))
@protocol SharedAnalyticEvent
@required
- (BOOL)isAppsFlyer __attribute__((swift_name("isAppsFlyer()")));
- (BOOL)isBraze __attribute__((swift_name("isBraze()")));
- (BOOL)isDevCycle __attribute__((swift_name("isDevCycle()")));
- (BOOL)isMixpanel __attribute__((swift_name("isMixpanel()")));
- (BOOL)isSegment __attribute__((swift_name("isSegment()")));
@property (readonly) NSArray<SharedDestination *> *destinations __attribute__((swift_name("destinations")));
@property (readonly) BOOL flushImmediately __attribute__((swift_name("flushImmediately")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol SharedKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface SharedKotlinEnum<E> : SharedBase <SharedKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Destination")))
@interface SharedDestination : SharedKotlinEnum<SharedDestination *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDestination *segment __attribute__((swift_name("segment")));
@property (class, readonly) SharedDestination *braze __attribute__((swift_name("braze")));
@property (class, readonly) SharedDestination *devcycle __attribute__((swift_name("devcycle")));
@property (class, readonly) SharedDestination *appsflyer __attribute__((swift_name("appsflyer")));
@property (class, readonly) SharedDestination *mixpanel __attribute__((swift_name("mixpanel")));
+ (SharedKotlinArray<SharedDestination *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedDestination *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IdentifyEvent")))
@interface SharedIdentifyEvent : SharedBase <SharedAnalyticEvent>
- (instancetype)initWithProperties:(SharedIdentifyProperties *)properties flushImmediately:(BOOL)flushImmediately destinations:(NSArray<SharedDestination *> *)destinations __attribute__((swift_name("init(properties:flushImmediately:destinations:)"))) __attribute__((objc_designated_initializer));
- (SharedIdentifyEvent *)doCopyProperties:(SharedIdentifyProperties *)properties flushImmediately:(BOOL)flushImmediately destinations:(NSArray<SharedDestination *> *)destinations __attribute__((swift_name("doCopy(properties:flushImmediately:destinations:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SharedDestination *> *destinations __attribute__((swift_name("destinations")));
@property (readonly) BOOL flushImmediately __attribute__((swift_name("flushImmediately")));
@property (readonly) SharedIdentifyProperties *properties __attribute__((swift_name("properties")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IdentifyProperties")))
@interface SharedIdentifyProperties : SharedBase
- (instancetype)initWithUserId:(NSString * _Nullable)userId userEmail:(NSString * _Nullable)userEmail userPhone:(NSString * _Nullable)userPhone userBirthday:(NSString * _Nullable)userBirthday userCreateDate:(NSString * _Nullable)userCreateDate userLastName:(NSString * _Nullable)userLastName userFirstName:(NSString * _Nullable)userFirstName userZip:(NSString * _Nullable)userZip userCity:(NSString * _Nullable)userCity userState:(NSString * _Nullable)userState userStreet:(NSString * _Nullable)userStreet userIsFirstTime:(SharedBoolean * _Nullable)userIsFirstTime userNumBillsPaid:(SharedInt * _Nullable)userNumBillsPaid otherProperties:(NSDictionary<NSString *, id> * _Nullable)otherProperties __attribute__((swift_name("init(userId:userEmail:userPhone:userBirthday:userCreateDate:userLastName:userFirstName:userZip:userCity:userState:userStreet:userIsFirstTime:userNumBillsPaid:otherProperties:)"))) __attribute__((objc_designated_initializer));
- (SharedIdentifyProperties *)doCopyUserId:(NSString * _Nullable)userId userEmail:(NSString * _Nullable)userEmail userPhone:(NSString * _Nullable)userPhone userBirthday:(NSString * _Nullable)userBirthday userCreateDate:(NSString * _Nullable)userCreateDate userLastName:(NSString * _Nullable)userLastName userFirstName:(NSString * _Nullable)userFirstName userZip:(NSString * _Nullable)userZip userCity:(NSString * _Nullable)userCity userState:(NSString * _Nullable)userState userStreet:(NSString * _Nullable)userStreet userIsFirstTime:(SharedBoolean * _Nullable)userIsFirstTime userNumBillsPaid:(SharedInt * _Nullable)userNumBillsPaid otherProperties:(NSDictionary<NSString *, id> * _Nullable)otherProperties __attribute__((swift_name("doCopy(userId:userEmail:userPhone:userBirthday:userCreateDate:userLastName:userFirstName:userZip:userCity:userState:userStreet:userIsFirstTime:userNumBillsPaid:otherProperties:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSDictionary<NSString *, id> * _Nullable otherProperties __attribute__((swift_name("otherProperties")));
@property NSString * _Nullable userBirthday __attribute__((swift_name("userBirthday")));
@property NSString * _Nullable userCity __attribute__((swift_name("userCity")));
@property NSString * _Nullable userCreateDate __attribute__((swift_name("userCreateDate")));
@property NSString * _Nullable userEmail __attribute__((swift_name("userEmail")));
@property NSString * _Nullable userFirstName __attribute__((swift_name("userFirstName")));
@property NSString * _Nullable userId __attribute__((swift_name("userId")));
@property SharedBoolean * _Nullable userIsFirstTime __attribute__((swift_name("userIsFirstTime")));
@property NSString * _Nullable userLastName __attribute__((swift_name("userLastName")));
@property SharedInt * _Nullable userNumBillsPaid __attribute__((swift_name("userNumBillsPaid")));
@property NSString * _Nullable userPhone __attribute__((swift_name("userPhone")));
@property NSString * _Nullable userState __attribute__((swift_name("userState")));
@property NSString * _Nullable userStreet __attribute__((swift_name("userStreet")));
@property NSString * _Nullable userZip __attribute__((swift_name("userZip")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SuperProperties")))
@interface SharedSuperProperties : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedSuperPropertiesCompanion *companion __attribute__((swift_name("companion")));
- (NSDictionary<NSString *, id> *)getProperties __attribute__((swift_name("getProperties()")));
- (void)removePropertyKey:(NSString *)key __attribute__((swift_name("removeProperty(key:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)setExperimentsExperiments:(NSDictionary<NSString *, NSString *> *)experiments __attribute__((swift_name("setExperiments(experiments:)")));
- (void)setPropertyKey:(NSString *)key value:(id)value __attribute__((swift_name("setProperty(key:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SuperProperties.Companion")))
@interface SharedSuperPropertiesCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedSuperPropertiesCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *EXPERIMENTS_KEY __attribute__((swift_name("EXPERIMENTS_KEY")));
@property (readonly) NSString *PLATFORM_KEY __attribute__((swift_name("PLATFORM_KEY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimeEvent")))
@interface SharedTimeEvent : SharedBase <SharedAnalyticEvent>
- (instancetype)initWithEventName:(NSString *)eventName properties:(NSDictionary<NSString *, id> *)properties loadingTime:(int64_t)loadingTime flushImmediately:(BOOL)flushImmediately destinations:(NSArray<SharedDestination *> *)destinations __attribute__((swift_name("init(eventName:properties:loadingTime:flushImmediately:destinations:)"))) __attribute__((objc_designated_initializer));
- (SharedTimeEvent *)doCopyEventName:(NSString *)eventName properties:(NSDictionary<NSString *, id> *)properties loadingTime:(int64_t)loadingTime flushImmediately:(BOOL)flushImmediately destinations:(NSArray<SharedDestination *> *)destinations __attribute__((swift_name("doCopy(eventName:properties:loadingTime:flushImmediately:destinations:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedTrackEvent *)toTrackEvent __attribute__((swift_name("toTrackEvent()")));
@property (readonly) NSArray<SharedDestination *> *destinations __attribute__((swift_name("destinations")));
@property (readonly) NSString *eventName __attribute__((swift_name("eventName")));
@property (readonly) BOOL flushImmediately __attribute__((swift_name("flushImmediately")));
@property (readonly) int64_t loadingTime __attribute__((swift_name("loadingTime")));
@property (readonly) NSDictionary<NSString *, id> *properties __attribute__((swift_name("properties")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TrackEvent")))
@interface SharedTrackEvent : SharedBase <SharedAnalyticEvent>
- (instancetype)initWithEventName:(NSString *)eventName properties:(NSDictionary<NSString *, id> *)properties flushImmediately:(BOOL)flushImmediately destinations:(NSArray<SharedDestination *> *)destinations __attribute__((swift_name("init(eventName:properties:flushImmediately:destinations:)"))) __attribute__((objc_designated_initializer));
- (SharedTrackEvent *)doCopyEventName:(NSString *)eventName properties:(NSDictionary<NSString *, id> *)properties flushImmediately:(BOOL)flushImmediately destinations:(NSArray<SharedDestination *> *)destinations __attribute__((swift_name("doCopy(eventName:properties:flushImmediately:destinations:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SharedDestination *> *destinations __attribute__((swift_name("destinations")));
@property (readonly) NSString *eventName __attribute__((swift_name("eventName")));
@property (readonly) BOOL flushImmediately __attribute__((swift_name("flushImmediately")));
@property (readonly) NSDictionary<NSString *, id> *properties __attribute__((swift_name("properties")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TrackProperties")))
@interface SharedTrackProperties : SharedBase
- (instancetype)initWithBillDate:(NSString * _Nullable)billDate billType:(NSString * _Nullable)billType billPayee:(NSString * _Nullable)billPayee billStatus:(NSString * _Nullable)billStatus billAmount:(NSString * _Nullable)billAmount billServerId:(NSString * _Nullable)billServerId billDueAmount:(NSString * _Nullable)billDueAmount billIsPartial:(SharedBoolean * _Nullable)billIsPartial billIsPartner:(SharedBoolean * _Nullable)billIsPartner billIsRequireExtraInfo:(SharedBoolean * _Nullable)billIsRequireExtraInfo billEnteredProvider:(NSString * _Nullable)billEnteredProvider billEnteredAccountNumber:(NSString * _Nullable)billEnteredAccountNumber billIsSchedule:(SharedBoolean * _Nullable)billIsSchedule billMerchantFee:(NSString * _Nullable)billMerchantFee billPayeeACHFee:(NSString * _Nullable)billPayeeACHFee billPayeeDebitCardFee:(NSString * _Nullable)billPayeeDebitCardFee billPayeeCreditCardFee:(NSString * _Nullable)billPayeeCreditCardFee billPapayaDebitCardFee:(NSString * _Nullable)billPapayaDebitCardFee billPapayaCreditCardFee:(NSString * _Nullable)billPapayaCreditCardFee paymentMethodName:(NSString * _Nullable)paymentMethodName paymentMethodType:(NSString * _Nullable)paymentMethodType __attribute__((swift_name("init(billDate:billType:billPayee:billStatus:billAmount:billServerId:billDueAmount:billIsPartial:billIsPartner:billIsRequireExtraInfo:billEnteredProvider:billEnteredAccountNumber:billIsSchedule:billMerchantFee:billPayeeACHFee:billPayeeDebitCardFee:billPayeeCreditCardFee:billPapayaDebitCardFee:billPapayaCreditCardFee:paymentMethodName:paymentMethodType:)"))) __attribute__((objc_designated_initializer));
- (SharedTrackProperties *)doCopyBillDate:(NSString * _Nullable)billDate billType:(NSString * _Nullable)billType billPayee:(NSString * _Nullable)billPayee billStatus:(NSString * _Nullable)billStatus billAmount:(NSString * _Nullable)billAmount billServerId:(NSString * _Nullable)billServerId billDueAmount:(NSString * _Nullable)billDueAmount billIsPartial:(SharedBoolean * _Nullable)billIsPartial billIsPartner:(SharedBoolean * _Nullable)billIsPartner billIsRequireExtraInfo:(SharedBoolean * _Nullable)billIsRequireExtraInfo billEnteredProvider:(NSString * _Nullable)billEnteredProvider billEnteredAccountNumber:(NSString * _Nullable)billEnteredAccountNumber billIsSchedule:(SharedBoolean * _Nullable)billIsSchedule billMerchantFee:(NSString * _Nullable)billMerchantFee billPayeeACHFee:(NSString * _Nullable)billPayeeACHFee billPayeeDebitCardFee:(NSString * _Nullable)billPayeeDebitCardFee billPayeeCreditCardFee:(NSString * _Nullable)billPayeeCreditCardFee billPapayaDebitCardFee:(NSString * _Nullable)billPapayaDebitCardFee billPapayaCreditCardFee:(NSString * _Nullable)billPapayaCreditCardFee paymentMethodName:(NSString * _Nullable)paymentMethodName paymentMethodType:(NSString * _Nullable)paymentMethodType __attribute__((swift_name("doCopy(billDate:billType:billPayee:billStatus:billAmount:billServerId:billDueAmount:billIsPartial:billIsPartner:billIsRequireExtraInfo:billEnteredProvider:billEnteredAccountNumber:billIsSchedule:billMerchantFee:billPayeeACHFee:billPayeeDebitCardFee:billPayeeCreditCardFee:billPapayaDebitCardFee:billPapayaCreditCardFee:paymentMethodName:paymentMethodType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable billAmount __attribute__((swift_name("billAmount")));
@property NSString * _Nullable billDate __attribute__((swift_name("billDate")));
@property NSString * _Nullable billDueAmount __attribute__((swift_name("billDueAmount")));
@property NSString * _Nullable billEnteredAccountNumber __attribute__((swift_name("billEnteredAccountNumber")));
@property NSString * _Nullable billEnteredProvider __attribute__((swift_name("billEnteredProvider")));
@property SharedBoolean * _Nullable billIsPartial __attribute__((swift_name("billIsPartial")));
@property SharedBoolean * _Nullable billIsPartner __attribute__((swift_name("billIsPartner")));
@property SharedBoolean * _Nullable billIsRequireExtraInfo __attribute__((swift_name("billIsRequireExtraInfo")));
@property SharedBoolean * _Nullable billIsSchedule __attribute__((swift_name("billIsSchedule")));
@property NSString * _Nullable billMerchantFee __attribute__((swift_name("billMerchantFee")));
@property NSString * _Nullable billPapayaCreditCardFee __attribute__((swift_name("billPapayaCreditCardFee")));
@property NSString * _Nullable billPapayaDebitCardFee __attribute__((swift_name("billPapayaDebitCardFee")));
@property NSString * _Nullable billPayee __attribute__((swift_name("billPayee")));
@property NSString * _Nullable billPayeeACHFee __attribute__((swift_name("billPayeeACHFee")));
@property NSString * _Nullable billPayeeCreditCardFee __attribute__((swift_name("billPayeeCreditCardFee")));
@property NSString * _Nullable billPayeeDebitCardFee __attribute__((swift_name("billPayeeDebitCardFee")));
@property NSString * _Nullable billServerId __attribute__((swift_name("billServerId")));
@property NSString * _Nullable billStatus __attribute__((swift_name("billStatus")));
@property NSString * _Nullable billType __attribute__((swift_name("billType")));
@property NSString * _Nullable paymentMethodName __attribute__((swift_name("paymentMethodName")));
@property NSString * _Nullable paymentMethodType __attribute__((swift_name("paymentMethodType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccountDeletionStatus")))
@interface SharedAccountDeletionStatus : SharedKotlinEnum<SharedAccountDeletionStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedAccountDeletionStatus *success __attribute__((swift_name("success")));
@property (class, readonly) SharedAccountDeletionStatus *billsPendingError __attribute__((swift_name("billsPendingError")));
@property (class, readonly) SharedAccountDeletionStatus *activeSubscriptionError __attribute__((swift_name("activeSubscriptionError")));
@property (class, readonly) SharedAccountDeletionStatus *genericError __attribute__((swift_name("genericError")));
+ (SharedKotlinArray<SharedAccountDeletionStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedAccountDeletionStatus *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *statusDescription __attribute__((swift_name("statusDescription")));
@end

__attribute__((swift_name("PermissionSource")))
@interface SharedPermissionSource : SharedBase
@property (readonly) NSString *sourceName __attribute__((swift_name("sourceName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PermissionSource.Account")))
@interface SharedPermissionSourceAccount : SharedPermissionSource
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)account __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedPermissionSourceAccount *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PermissionSource.BillDetails")))
@interface SharedPermissionSourceBillDetails : SharedPermissionSource
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)billDetails __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedPermissionSourceBillDetails *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PermissionSource.BillSubmitted")))
@interface SharedPermissionSourceBillSubmitted : SharedPermissionSource
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)billSubmitted __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedPermissionSourceBillSubmitted *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyDashboardStatus")))
@interface SharedPrivacyDashboardStatus : SharedKotlinEnum<SharedPrivacyDashboardStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedPrivacyDashboardStatus *inProgress __attribute__((swift_name("inProgress")));
@property (class, readonly) SharedPrivacyDashboardStatus *actionRequired __attribute__((swift_name("actionRequired")));
@property (class, readonly) SharedPrivacyDashboardStatus *completed __attribute__((swift_name("completed")));
@property (class, readonly) SharedPrivacyDashboardStatus *exposed __attribute__((swift_name("exposed")));
+ (SharedKotlinArray<SharedPrivacyDashboardStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedPrivacyDashboardStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ProductExposureSource")))
@interface SharedProductExposureSource : SharedKotlinEnum<SharedProductExposureSource *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedProductExposureSource *homeScreen __attribute__((swift_name("homeScreen")));
@property (class, readonly) SharedProductExposureSource *privacyTab __attribute__((swift_name("privacyTab")));
@property (class, readonly) SharedProductExposureSource *postBill __attribute__((swift_name("postBill")));
@property (class, readonly) SharedProductExposureSource *billHistory __attribute__((swift_name("billHistory")));
+ (SharedKotlinArray<SharedProductExposureSource *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedProductExposureSource *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TabBarItem")))
@interface SharedTabBarItem : SharedKotlinEnum<SharedTabBarItem *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedTabBarItem *home __attribute__((swift_name("home")));
@property (class, readonly) SharedTabBarItem *bills __attribute__((swift_name("bills")));
@property (class, readonly) SharedTabBarItem *privacy __attribute__((swift_name("privacy")));
@property (class, readonly) SharedTabBarItem *account __attribute__((swift_name("account")));
+ (SharedKotlinArray<SharedTabBarItem *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedTabBarItem *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *tabItemName __attribute__((swift_name("tabItemName")));
@end

__attribute__((swift_name("AnalyticsReceiver")))
@protocol SharedAnalyticsReceiver
@required
- (void)onFlush __attribute__((swift_name("onFlush()")));
- (void)onIdentifyEventIdentifyEvent:(SharedIdentifyEvent *)identifyEvent __attribute__((swift_name("onIdentifyEvent(identifyEvent:)")));
- (void)onReset __attribute__((swift_name("onReset()")));
- (void)onTrackEventTrackEvent:(SharedTrackEvent *)trackEvent superProperties:(NSDictionary<NSString *, id> *)superProperties __attribute__((swift_name("onTrackEvent(trackEvent:superProperties:)")));
@end

__attribute__((swift_name("ErrorTracker")))
@protocol SharedErrorTracker
@required
- (void)trackAPIFailedEndpoint:(NSString *)endpoint errorCode:(NSString * _Nullable)errorCode errorMessage:(NSString * _Nullable)errorMessage __attribute__((swift_name("trackAPIFailed(endpoint:errorCode:errorMessage:)")));
@end

__attribute__((swift_name("EventTracker")))
@protocol SharedEventTracker
@required
- (void)accountDeletionCompletedStatus:(SharedAccountDeletionStatus *)status __attribute__((swift_name("accountDeletionCompleted(status:)")));
- (void)accountNumberSavedNewAccountNumber:(NSString *)newAccountNumber billId:(NSString *)billId __attribute__((swift_name("accountNumberSaved(newAccountNumber:billId:)")));
- (void)accountViewShown __attribute__((swift_name("accountViewShown()")));
- (void)addBankAccountCTAClickedView:(NSString *)view __attribute__((swift_name("addBankAccountCTAClicked(view:)")));
- (void)amountSavedNewAmount:(NSString *)newAmount billId:(NSString *)billId __attribute__((swift_name("amountSaved(newAmount:billId:)")));
- (void)amountViewAmountConfirmedAmount:(NSString *)amount __attribute__((swift_name("amountViewAmountConfirmed(amount:)")));
- (void)amountViewShownTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("amountViewShown(trackProperties:)")));
- (void)amountViewTappedBillImageThumbnail __attribute__((swift_name("amountViewTappedBillImageThumbnail()")));
- (void)analyticsInitialized __attribute__((swift_name("analyticsInitialized()")));
- (void)appGoToBackground __attribute__((swift_name("appGoToBackground()")));
- (void)appLaunchFinishedTime:(int64_t)time __attribute__((swift_name("appLaunchFinished(time:)")));
- (void)appLaunchTimedOut __attribute__((swift_name("appLaunchTimedOut()")));
- (void)appLaunched __attribute__((swift_name("appLaunched()")));
- (void)appResumed __attribute__((swift_name("appResumed()")));
- (void)appReviewAlertRequested __attribute__((swift_name("appReviewAlertRequested()")));
- (void)appReviewAlertShouldShown __attribute__((swift_name("appReviewAlertShouldShown()")));
- (void)bankAccountEntryViewShown __attribute__((swift_name("bankAccountEntryViewShown()")));
- (void)billCancelledCancellationReason:(NSString *)cancellationReason otherBillProperties:(SharedTrackProperties *)otherBillProperties __attribute__((swift_name("billCancelled(cancellationReason:otherBillProperties:)")));
- (void)billDetailViewShownTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("billDetailViewShown(trackProperties:)")));
- (void)billEditedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("billEdited(trackProperties:)")));
- (void)billHistoryPrivacyBannerClicked __attribute__((swift_name("billHistoryPrivacyBannerClicked()")));
- (void)billHistoryPrivacyBannerHidden __attribute__((swift_name("billHistoryPrivacyBannerHidden()")));
- (void)billHistoryTappedViewBillDetailsTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("billHistoryTappedViewBillDetails(trackProperties:)")));
- (void)billHistoryViewShown __attribute__((swift_name("billHistoryViewShown()")));
- (void)billImageDownloadSelected __attribute__((swift_name("billImageDownloadSelected()")));
- (void)billImageExpandShown __attribute__((swift_name("billImageExpandShown()")));
- (void)billImageExpandTappedClose __attribute__((swift_name("billImageExpandTappedClose()")));
- (void)billImageUploadSource:(NSString *)source originalSize:(int64_t)originalSize formattedSize:(int64_t)formattedSize isProbableScreenShot:(BOOL)isProbableScreenShot __attribute__((swift_name("billImageUpload(source:originalSize:formattedSize:isProbableScreenShot:)")));
- (void)billInformationMissingBillId:(NSString *)billId __attribute__((swift_name("billInformationMissing(billId:)")));
- (void)billPaymentReviewScreenClickedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("billPaymentReviewScreenClicked(trackProperties:)")));
- (void)billPaymentReviewScreenShownTrackProperties:(SharedTrackProperties *)trackProperties isPapayaFee:(SharedBoolean * _Nullable)isPapayaFee __attribute__((swift_name("billPaymentReviewScreenShown(trackProperties:isPapayaFee:)")));
- (void)billScanScreenShown __attribute__((swift_name("billScanScreenShown()")));
- (void)billScheduledTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("billScheduled(trackProperties:)")));
- (void)billSubmittedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("billSubmitted(trackProperties:)")));
- (void)billSubmittedConfirmationContinueCTAClicked __attribute__((swift_name("billSubmittedConfirmationContinueCTAClicked()")));
- (void)billSubmittedDialogDismissedType:(NSString *)type __attribute__((swift_name("billSubmittedDialogDismissed(type:)")));
- (void)billSubmittedDialogShown __attribute__((swift_name("billSubmittedDialogShown()")));
- (void)billerNameSavedNewName:(NSString *)newName billId:(NSString *)billId __attribute__((swift_name("billerNameSaved(newName:billId:)")));
- (void)brazePushNotificationCreatedTitle:(NSString *)title __attribute__((swift_name("brazePushNotificationCreated(title:)")));
- (void)brazePushNotificationHandledTitle:(NSString *)title __attribute__((swift_name("brazePushNotificationHandled(title:)")));
- (void)cameraBillCancel __attribute__((swift_name("cameraBillCancel()")));
- (void)cameraViewAcceptCameraPermission __attribute__((swift_name("cameraViewAcceptCameraPermission()")));
- (void)cameraViewChooseImageFromLibraryRetaken:(BOOL)retaken __attribute__((swift_name("cameraViewChooseImageFromLibrary(retaken:)")));
- (void)cameraViewDeniedCameraPermission __attribute__((swift_name("cameraViewDeniedCameraPermission()")));
- (void)cameraViewGoToSettings __attribute__((swift_name("cameraViewGoToSettings()")));
- (void)cameraViewPhotoCapturedRetaken:(BOOL)retaken __attribute__((swift_name("cameraViewPhotoCaptured(retaken:)")));
- (void)cameraViewRequestCameraPermission __attribute__((swift_name("cameraViewRequestCameraPermission()")));
- (void)cameraViewSelectFileButtonTapped __attribute__((swift_name("cameraViewSelectFileButtonTapped()")));
- (void)cameraViewSelectFileCancelled __attribute__((swift_name("cameraViewSelectFileCancelled()")));
- (void)cameraViewSelectFilePermissionDenied __attribute__((swift_name("cameraViewSelectFilePermissionDenied()")));
- (void)cameraViewSelectFilePermissionGranted __attribute__((swift_name("cameraViewSelectFilePermissionGranted()")));
- (void)cameraViewSelectFilePermissionRationaleCancelled __attribute__((swift_name("cameraViewSelectFilePermissionRationaleCancelled()")));
- (void)cameraViewSelectFilePermissionRationalePermitted __attribute__((swift_name("cameraViewSelectFilePermissionRationalePermitted()")));
- (void)cameraViewSelectFilePermissionSettingsCancelled __attribute__((swift_name("cameraViewSelectFilePermissionSettingsCancelled()")));
- (void)cameraViewSelectFilePermissionSettingsNavigated __attribute__((swift_name("cameraViewSelectFilePermissionSettingsNavigated()")));
- (void)cameraViewSelectFileSuccessFileFormat:(NSString *)fileFormat __attribute__((swift_name("cameraViewSelectFileSuccess(fileFormat:)")));
- (void)cameraViewSelectGalleryButtonTapped __attribute__((swift_name("cameraViewSelectGalleryButtonTapped()")));
- (void)cameraViewSelectGalleryCancelled __attribute__((swift_name("cameraViewSelectGalleryCancelled()")));
- (void)cameraViewSelectGallerySuccessFileFormat:(NSString *)fileFormat __attribute__((swift_name("cameraViewSelectGallerySuccess(fileFormat:)")));
- (void)cameraViewShown __attribute__((swift_name("cameraViewShown()")));
- (void)cardEntryViewShown __attribute__((swift_name("cardEntryViewShown()")));
- (void)changedPaymentMethodTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("changedPaymentMethod(trackProperties:)")));
- (void)chooseFileOptionSearchedBiller:(NSString * _Nullable)searchedBiller __attribute__((swift_name("chooseFileOption(searchedBiller:)")));
- (void)continueWithOutReenterCardName __attribute__((swift_name("continueWithOutReenterCardName()")));
- (void)customEventTrackEvent:(SharedTrackEvent *)trackEvent __attribute__((swift_name("customEvent(trackEvent:)")));
- (void)deepLinkOpenedMethod:(NSString *)method message:(NSString * _Nullable)message destination:(NSString * _Nullable)destination __attribute__((swift_name("deepLinkOpened(method:message:destination:)")));
- (void)devCycleFailedError:(NSString *)error __attribute__((swift_name("devCycleFailed(error:)")));
- (void)devCycleLoadedTime:(int64_t)time __attribute__((swift_name("devCycleLoaded(time:)")));
- (void)dobScreenCTAClicked __attribute__((swift_name("dobScreenCTAClicked()")));
- (void)dobScreenShown __attribute__((swift_name("dobScreenShown()")));
- (void)editAccountNumberClickedCurrentAccountNumber:(NSString *)currentAccountNumber billId:(NSString *)billId __attribute__((swift_name("editAccountNumberClicked(currentAccountNumber:billId:)")));
- (void)editAmountClickedCurrentAmount:(NSString *)currentAmount billId:(NSString *)billId __attribute__((swift_name("editAmountClicked(currentAmount:billId:)")));
- (void)editBillerNameClickedCurrentName:(NSString *)currentName billId:(NSString *)billId __attribute__((swift_name("editBillerNameClicked(currentName:billId:)")));
- (void)extraInfoViewCTATappedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("extraInfoViewCTATapped(trackProperties:)")));
- (void)extraInfoViewShownTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("extraInfoViewShown(trackProperties:)")));
- (void)forethoughtWidgetExitLocation:(NSString *)location __attribute__((swift_name("forethoughtWidgetExit(location:)")));
- (void)forethoughtWidgetShownLocation:(NSString *)location __attribute__((swift_name("forethoughtWidgetShown(location:)")));
- (void)graphqlInterceptorInvalidToken __attribute__((swift_name("graphqlInterceptorInvalidToken()")));
- (void)graphqlTokenRefreshed __attribute__((swift_name("graphqlTokenRefreshed()")));
- (void)homeCardClickedHomeCardName:(NSString *)homeCardName __attribute__((swift_name("homeCardClicked(homeCardName:)")));
- (void)homeCardDestinationButtonTappedHomeCardName:(NSString *)homeCardName __attribute__((swift_name("homeCardDestinationButtonTapped(homeCardName:)")));
- (void)homeCardDismissedHomeCardName:(NSString *)homeCardName __attribute__((swift_name("homeCardDismissed(homeCardName:)")));
- (void)homeScreenPayBillClicked __attribute__((swift_name("homeScreenPayBillClicked()")));
- (void)homeScreenShown __attribute__((swift_name("homeScreenShown()")));
- (void)incompleteBillDiscardedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("incompleteBillDiscarded(trackProperties:)")));
- (void)kYCFailureShown __attribute__((swift_name("kYCFailureShown()")));
- (void)mavenHelpWidgetExitedLocation:(NSString *)location __attribute__((swift_name("mavenHelpWidgetExited(location:)")));
- (void)mavenHelpWidgetShownLocation:(NSString *)location __attribute__((swift_name("mavenHelpWidgetShown(location:)")));
- (void)migrationSupportAlertCtaClicked __attribute__((swift_name("migrationSupportAlertCtaClicked()")));
- (void)migrationSupportAlertDismissed __attribute__((swift_name("migrationSupportAlertDismissed()")));
- (void)migrationSupportAlertShown __attribute__((swift_name("migrationSupportAlertShown()")));
- (void)migrationSupportRequired __attribute__((swift_name("migrationSupportRequired()")));
- (void)myAccountSubscriptionManagementTapped __attribute__((swift_name("myAccountSubscriptionManagementTapped()")));
- (void)nextClicked __attribute__((swift_name("nextClicked()")));
- (void)nextTapped __attribute__((swift_name("nextTapped()")));
- (void)ocrAlertDismissedCase:(NSString *)case_ resolution:(NSString *)resolution missingFields:(NSString *)missingFields trackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("ocrAlertDismissed(case:resolution:missingFields:trackProperties:)")));
- (void)ocrAlertShownCase:(NSString *)case_ missingFields:(NSString *)missingFields trackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("ocrAlertShown(case:missingFields:trackProperties:)")));
- (void)ocrInfoReceivedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("ocrInfoReceived(trackProperties:)")));
- (void)onboardingScreenCardOptionTapped __attribute__((swift_name("onboardingScreenCardOptionTapped()")));
- (void)onboardingScreenPayBillOptionTapped __attribute__((swift_name("onboardingScreenPayBillOptionTapped()")));
- (void)onboardingScreenPrivacyOptionTapped __attribute__((swift_name("onboardingScreenPrivacyOptionTapped()")));
- (void)onboardingScreenShown __attribute__((swift_name("onboardingScreenShown()")));
- (void)onboardingSignInTapped __attribute__((swift_name("onboardingSignInTapped()")));
- (void)papayaWebViewLoadedUrl:(NSString *)url time:(int64_t)time __attribute__((swift_name("papayaWebViewLoaded(url:time:)")));
- (void)payBillerAgainBillProperties:(SharedTrackProperties *)billProperties __attribute__((swift_name("payBillerAgain(billProperties:)")));
- (void)paymentAddressInfoViewShown __attribute__((swift_name("paymentAddressInfoViewShown()")));
- (void)paymentChoiceContinueCTAClickedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("paymentChoiceContinueCTAClicked(trackProperties:)")));
- (void)paymentChoicePayNowCTAClickedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("paymentChoicePayNowCTAClicked(trackProperties:)")));
- (void)paymentMethodAddedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("paymentMethodAdded(trackProperties:)")));
- (void)paymentMethodChoiceViewShownPreselectedMethod:(NSString *)preselectedMethod trackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("paymentMethodChoiceViewShown(preselectedMethod:trackProperties:)")));
- (void)paymentMethodSelectedTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("paymentMethodSelected(trackProperties:)")));
- (void)personaRequestedViewRefresh __attribute__((swift_name("personaRequestedViewRefresh()")));
- (void)personaRequestedViewShown __attribute__((swift_name("personaRequestedViewShown()")));
- (void)photoLibraryOptionSearchedBiller:(NSString * _Nullable)searchedBiller __attribute__((swift_name("photoLibraryOption(searchedBiller:)")));
- (void)plaidAccountCreationErrorErrorCode:(NSString *)errorCode errorMessage:(NSString *)errorMessage __attribute__((swift_name("plaidAccountCreationError(errorCode:errorMessage:)")));
- (void)plaidAccountCreationSucceededName:(NSString *)name id:(NSString *)id __attribute__((swift_name("plaidAccountCreationSucceeded(name:id:)")));
- (void)plaidContactInfoFormShown __attribute__((swift_name("plaidContactInfoFormShown()")));
- (void)privacyAgeScreenCTAClickedAge:(int32_t)age __attribute__((swift_name("privacyAgeScreenCTAClicked(age:)")));
- (void)privacyAgeScreenShown __attribute__((swift_name("privacyAgeScreenShown()")));
- (void)privacyAgeScreenSupportClicked __attribute__((swift_name("privacyAgeScreenSupportClicked()")));
- (void)privacyDashboardAgeCTAClicked __attribute__((swift_name("privacyDashboardAgeCTAClicked()")));
- (void)privacyDashboardAgeScreenShown __attribute__((swift_name("privacyDashboardAgeScreenShown()")));
- (void)privacyDashboardContactSupportClickedIsCall:(BOOL)isCall __attribute__((swift_name("privacyDashboardContactSupportClicked(isCall:)")));
- (void)privacyDashboardContactSupportShown __attribute__((swift_name("privacyDashboardContactSupportShown()")));
- (void)privacyDashboardErrorScreenShown __attribute__((swift_name("privacyDashboardErrorScreenShown()")));
- (void)privacyDashboardInfoCTAClicked __attribute__((swift_name("privacyDashboardInfoCTAClicked()")));
- (void)privacyDashboardInfoScreenShown __attribute__((swift_name("privacyDashboardInfoScreenShown()")));
- (void)privacyDashboardShownDay:(NSString * _Nullable)day state:(NSString * _Nullable)state __attribute__((swift_name("privacyDashboardShown(day:state:)")));
- (void)privacyDashboardStatusClickedAnalyticStatus:(SharedPrivacyDashboardStatus *)analyticStatus __attribute__((swift_name("privacyDashboardStatusClicked(analyticStatus:)")));
- (void)privacyDashboardSupportClicked __attribute__((swift_name("privacyDashboardSupportClicked()")));
- (void)privacyDashboardSupportOptionsClickedIsCancellation:(BOOL)isCancellation __attribute__((swift_name("privacyDashboardSupportOptionsClicked(isCancellation:)")));
- (void)privacyDashboardSupportOptionsShown __attribute__((swift_name("privacyDashboardSupportOptionsShown()")));
- (void)privacyDashboardSurveyBannerClickedIsPositive:(BOOL)isPositive __attribute__((swift_name("privacyDashboardSurveyBannerClicked(isPositive:)")));
- (void)privacyDashboardSurveyBannerShown __attribute__((swift_name("privacyDashboardSurveyBannerShown()")));
- (void)privacyDashboardSurveyClickedIsPositive:(BOOL)isPositive selectedReasons:(NSArray<NSString *> *)selectedReasons feedbackText:(NSString *)feedbackText __attribute__((swift_name("privacyDashboardSurveyClicked(isPositive:selectedReasons:feedbackText:)")));
- (void)privacyDashboardSurveyShownIsPositive:(BOOL)isPositive __attribute__((swift_name("privacyDashboardSurveyShown(isPositive:)")));
- (void)privacyDashboardWithoutEnrollmentScanEditClicked __attribute__((swift_name("privacyDashboardWithoutEnrollmentScanEditClicked()")));
- (void)privacyDashboardWithoutEnrollmentScanninginProgress __attribute__((swift_name("privacyDashboardWithoutEnrollmentScanninginProgress()")));
- (void)privacyDashboardWithoutEnrollmentShown __attribute__((swift_name("privacyDashboardWithoutEnrollmentShown()")));
- (void)privacyDashboardWithoutEnrollmentStartScanClicked __attribute__((swift_name("privacyDashboardWithoutEnrollmentStartScanClicked()")));
- (void)privacyLandingPageCTAClicked __attribute__((swift_name("privacyLandingPageCTAClicked()")));
- (void)privacyLandingPageShown __attribute__((swift_name("privacyLandingPageShown()")));
- (void)privacyProtectionHomeCardClicked __attribute__((swift_name("privacyProtectionHomeCardClicked()")));
- (void)privacyProtectionHomeCardHidden __attribute__((swift_name("privacyProtectionHomeCardHidden()")));
- (void)privacyProtectionHomeCardShown __attribute__((swift_name("privacyProtectionHomeCardShown()")));
- (void)privacyProtectionProductExposedSource:(SharedProductExposureSource *)source __attribute__((swift_name("privacyProtectionProductExposed(source:)")));
- (void)pushNotificationRequested __attribute__((swift_name("pushNotificationRequested()")));
- (void)pushNotificationResultPermissionSource:(SharedPermissionSource *)permissionSource isPermissionGranted:(BOOL)isPermissionGranted __attribute__((swift_name("pushNotificationResult(permissionSource:isPermissionGranted:)")));
- (void)reenterCardName __attribute__((swift_name("reenterCardName()")));
- (void)remoteConfigLoadingFailedError:(NSString *)error __attribute__((swift_name("remoteConfigLoadingFailed(error:)")));
- (void)removePaymentMethodTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("removePaymentMethod(trackProperties:)")));
- (void)scheduleButtonTapped __attribute__((swift_name("scheduleButtonTapped()")));
- (void)scheduleDateSelected __attribute__((swift_name("scheduleDateSelected()")));
- (void)scheduleDateSubmitted __attribute__((swift_name("scheduleDateSubmitted()")));
- (void)schedulePaymentCalendarPickerShown __attribute__((swift_name("schedulePaymentCalendarPickerShown()")));
- (void)sessionStarted __attribute__((swift_name("sessionStarted()")));
- (void)signUpSignInViewShownFlow:(NSString *)flow __attribute__((swift_name("signUpSignInViewShown(flow:)")));
- (void)standalonePaymentMethodsViewShown __attribute__((swift_name("standalonePaymentMethodsViewShown()")));
- (void)startSessionCredentialsExist __attribute__((swift_name("startSessionCredentialsExist()")));
- (void)startSessionCredentialsMissing __attribute__((swift_name("startSessionCredentialsMissing()")));
- (void)startSessionNewTokenSuccess __attribute__((swift_name("startSessionNewTokenSuccess()")));
- (void)startSessionRefreshTokenExists __attribute__((swift_name("startSessionRefreshTokenExists()")));
- (void)startSessionRefreshTokenMissing __attribute__((swift_name("startSessionRefreshTokenMissing()")));
- (void)startSessionSignedInWithCredentials __attribute__((swift_name("startSessionSignedInWithCredentials()")));
- (void)startSessionTempAccountCreated __attribute__((swift_name("startSessionTempAccountCreated()")));
- (void)subscriptionEditButtonTapped __attribute__((swift_name("subscriptionEditButtonTapped()")));
- (void)subscriptionManagementCancelSubscriptionCancelTapped __attribute__((swift_name("subscriptionManagementCancelSubscriptionCancelTapped()")));
- (void)subscriptionManagementCancelSubscriptionHalfSheetShown __attribute__((swift_name("subscriptionManagementCancelSubscriptionHalfSheetShown()")));
- (void)subscriptionManagementCancelSubscriptionSubmitTappedProduct:(NSString *)product reasons:(NSArray<NSString *> *)reasons comment:(NSString *)comment __attribute__((swift_name("subscriptionManagementCancelSubscriptionSubmitTapped(product:reasons:comment:)")));
- (void)subscriptionManagementCancelSubscriptionSuccessStateShown __attribute__((swift_name("subscriptionManagementCancelSubscriptionSuccessStateShown()")));
- (void)subscriptionManagementCancelSubscriptionSurveyPageShown __attribute__((swift_name("subscriptionManagementCancelSubscriptionSurveyPageShown()")));
- (void)subscriptionManagementCancelSubscriptionTapped __attribute__((swift_name("subscriptionManagementCancelSubscriptionTapped()")));
- (void)subscriptionManagementCancelTappedIsFreeTrial:(BOOL)isFreeTrial __attribute__((swift_name("subscriptionManagementCancelTapped(isFreeTrial:)")));
- (void)subscriptionManagementConfirmPaymentMethodCTATapped __attribute__((swift_name("subscriptionManagementConfirmPaymentMethodCTATapped()")));
- (void)subscriptionManagementConfirmPaymentMethodStateShown __attribute__((swift_name("subscriptionManagementConfirmPaymentMethodStateShown()")));
- (void)subscriptionManagementConfirmPaymentMethodTechnicalErrorStateShown __attribute__((swift_name("subscriptionManagementConfirmPaymentMethodTechnicalErrorStateShown()")));
- (void)subscriptionManagementEnterValidMethodStateShown __attribute__((swift_name("subscriptionManagementEnterValidMethodStateShown()")));
- (void)subscriptionManagementGoBackTapped __attribute__((swift_name("subscriptionManagementGoBackTapped()")));
- (void)subscriptionManagementScreenShown __attribute__((swift_name("subscriptionManagementScreenShown()")));
- (void)subscriptionManagementShown __attribute__((swift_name("subscriptionManagementShown()")));
- (void)subscriptionManagementSuccessLinkingPaymentShown __attribute__((swift_name("subscriptionManagementSuccessLinkingPaymentShown()")));
- (void)subscriptionUpdateFailed __attribute__((swift_name("subscriptionUpdateFailed()")));
- (void)subscriptionUpdateSuccess __attribute__((swift_name("subscriptionUpdateSuccess()")));
- (void)tabBarItemClickedTabBarItemAnalytic:(SharedTabBarItem *)tabBarItemAnalytic __attribute__((swift_name("tabBarItemClicked(tabBarItemAnalytic:)")));
- (void)takeAPictureOptionSearchedBiller:(NSString * _Nullable)searchedBiller __attribute__((swift_name("takeAPictureOption(searchedBiller:)")));
- (void)tappedAddBankAccountTappedFromView:(NSString *)tappedFromView __attribute__((swift_name("tappedAddBankAccount(tappedFromView:)")));
- (void)tappedAddBankAccountInstantView:(NSString *)view __attribute__((swift_name("tappedAddBankAccountInstant(view:)")));
- (void)tappedAddBankAccountManualView:(NSString *)view __attribute__((swift_name("tappedAddBankAccountManual(view:)")));
- (void)tappedAddCreditCardView:(NSString *)view __attribute__((swift_name("tappedAddCreditCard(view:)")));
- (void)tappedAddDebitCardView:(NSString *)view __attribute__((swift_name("tappedAddDebitCard(view:)")));
- (void)tappedSelectedPaymentTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("tappedSelectedPayment(trackProperties:)")));
- (void)timeLoadHomeCardDestinationImageHomeCardName:(NSString *)homeCardName time:(int64_t)time __attribute__((swift_name("timeLoadHomeCardDestinationImage(homeCardName:time:)")));
- (void)timingConfigFetchingTime:(int64_t)time __attribute__((swift_name("timingConfigFetching(time:)")));
- (void)unexpectedErrorShown __attribute__((swift_name("unexpectedErrorShown()")));
- (void)updateAppCTAClicked __attribute__((swift_name("updateAppCTAClicked()")));
- (void)updateAppScreenShown __attribute__((swift_name("updateAppScreenShown()")));
- (void)userSatisfactionPromptShown __attribute__((swift_name("userSatisfactionPromptShown()")));
- (void)userSatisfactionStoreReviewRequested __attribute__((swift_name("userSatisfactionStoreReviewRequested()")));
- (void)userSatisfactionSubmittedRating:(BOOL)rating comment:(NSString *)comment __attribute__((swift_name("userSatisfactionSubmitted(rating:comment:)")));
- (void)userSignInFailedEmail:(NSString *)email error:(NSString *)error flow:(NSString *)flow __attribute__((swift_name("userSignInFailed(email:error:flow:)")));
- (void)userSignOutFailedEmail:(NSString *)email error:(NSString *)error __attribute__((swift_name("userSignOutFailed(email:error:)")));
- (void)userSignUpFailedEmail:(NSString *)email error:(NSString *)error flow:(NSString *)flow __attribute__((swift_name("userSignUpFailed(email:error:flow:)")));
- (void)userSignedInEmail:(NSString *)email flow:(NSString *)flow __attribute__((swift_name("userSignedIn(email:flow:)")));
- (void)userSignedOutEmail:(NSString *)email __attribute__((swift_name("userSignedOut(email:)")));
- (void)userSignedUpEmail:(NSString *)email flow:(NSString *)flow __attribute__((swift_name("userSignedUp(email:flow:)")));
- (void)vgsTokenizationFailed __attribute__((swift_name("vgsTokenizationFailed()")));
- (void)vgsTokenizationSucceeded __attribute__((swift_name("vgsTokenizationSucceeded()")));
- (void)viewedFeeInformationTrackProperties:(SharedTrackProperties *)trackProperties __attribute__((swift_name("viewedFeeInformation(trackProperties:)")));
- (void)wpbpMergeUserAccountSuccess:(BOOL)success __attribute__((swift_name("wpbpMergeUserAccount(success:)")));
@end

__attribute__((swift_name("IdentifyTracker")))
@protocol SharedIdentifyTracker
@required
- (void)identifyIdentifyProps:(SharedIdentifyProperties *)identifyProps __attribute__((swift_name("identify(identifyProps:)")));
@end

@interface SharedIdentifyEvent (Extensions)
- (NSDictionary<NSString *, id> *)toMixpanelPeople __attribute__((swift_name("toMixpanelPeople()")));
@end

@interface SharedIdentifyProperties (Extensions)
- (NSDictionary<NSString *, id> *)toMixpanelPeople __attribute__((swift_name("toMixpanelPeople()")));
@end

@interface SharedTrackProperties (Extensions)
- (NSDictionary<NSString *, id> *)toNamedProperties __attribute__((swift_name("toNamedProperties()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform_iosKt")))
@interface SharedPlatform_iosKt : SharedBase
+ (id<SharedPlatform>)getPlatform __attribute__((swift_name("getPlatform()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StringExtKt")))
@interface SharedStringExtKt : SharedBase
+ (NSString *)toExperimentGroupString:(NSString *)receiver __attribute__((swift_name("toExperimentGroupString(_:)")));
+ (NSString *)toExperimentNumberString:(NSString *)receiver __attribute__((swift_name("toExperimentNumberString(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface SharedKotlinEnumCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SharedKotlinArray<T> : SharedBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SharedKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol SharedKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
